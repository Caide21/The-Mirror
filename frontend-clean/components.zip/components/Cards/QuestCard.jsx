import Link from 'next/link';

export default function ScrollCard({ scroll }) {
  return (
    <div
      className="relative p-6 rounded-2xl shadow-lg theme-card mb-6 overflow-hidden"
      style={{
        backgroundImage: `url('/parchment-texture.png')`,
        backgroundSize: 'cover',
        backgroundRepeat: 'repeat',
      }}
    >
      {/* Enchantment Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-transparent to-yellow-50 opacity-10 pointer-events-none" />

      {/* Optional Glyph or Sigil */}
      <div className="absolute top-4 right-4 text-4xl opacity-30 pointer-events-none">
        {scroll.symbol}
      </div>

      <h1 className="text-2xl font-serif font-bold mb-2">{scroll.title}</h1>
      <p className="italic mb-4">{scroll.essence}</p>
      
      <h2 className="text-lg font-semibold mb-1">Core Law</h2>
      <p className="mb-4">{scroll.coreLaw}</p>

      <h2 className="text-lg font-semibold mb-1">Ritual</h2>
      <p className="mb-4">{scroll.ritual}</p>

      <Link
        href={`/scrolls/${scroll.slug}`}
        className="text-theme-accent text-sm underline"
      >
        Open Scroll →
      </Link>
    </div>
  );
}
