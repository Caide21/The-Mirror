import ScrollPage from './ScrollPage'
import RitualPage from './Control_Components/RitualPage'
import CodexSlugPage from './Pages/CodexSlugPage'
import QuestDetail from './Mirror/QuestDetail'

import ScrollCard from './Cards/ScrollCard'
import RitualCard from './Cards/RitualCard'
import CodexCard from './Cards/CodexCard'
import QuestCard from './Cards/QuestCard'

export default function SmartRenderer({ page, mode = 'card' }) {
  const properties = page.properties

  const type = properties.Type?.select?.name || ''
  const props = {
    title: properties.Name?.title[0]?.plain_text || '',
    slug: properties.Slug?.rich_text[0]?.plain_text || '',
    description: properties.Description?.rich_text[0]?.plain_text || '',
    symbol: properties.Symbol?.rich_text[0]?.plain_text || '',
    essence: properties.Essence?.rich_text[0]?.plain_text || '',
    coreLaw: properties.CoreLaw?.rich_text[0]?.plain_text || '',
    ritual: properties.Ritual?.rich_text[0]?.plain_text || ''
  }

  if (mode === 'card') {
    if (type === 'Scroll') return <ScrollCard {...props} />
    if (type === 'Ritual') return <RitualCard {...props} />
    if (type === 'Codex') return <CodexCard {...props} />
    if (type === 'Quest') return <QuestCard {...props} />
  }

  if (mode === 'detail') {
    if (type === 'Scroll') return <ScrollPage {...props} />
    if (type === 'Ritual') return <RitualPage {...props} />
    if (type === 'Codex') return <CodexSlugPage {...props} />
    if (type === 'Quest') return <QuestDetail {...props} />
  }

  return <div>Unknown Type</div>
}
